from django.apps import AppConfig


class GranitizerConfig(AppConfig):
    name = 'granitizer'
