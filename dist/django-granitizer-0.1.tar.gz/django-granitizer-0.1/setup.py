from setuptools import setup

setup(name="django-granitizer",
    version="0.1",
)
